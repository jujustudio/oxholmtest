---
title: 'Thank you'
permalink: '/thank-you/index.html'
---

This is your thank you page where if someone fills in your contact form, they will be directed to. Make sure you add a nice message 🙂
